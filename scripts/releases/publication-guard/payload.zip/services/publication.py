"""Services responsible for publishing queued items to Telegram."""

from __future__ import annotations

import html
import logging
from datetime import datetime, timedelta, timezone
from functools import partial
from pathlib import Path
from typing import Any, Callable, Mapping, TYPE_CHECKING
from urllib.parse import urlparse
import aiosqlite
import asyncio
from aiogram.exceptions import (
    TelegramBadRequest,
    TelegramForbiddenError,
    TelegramNotFound,
    TelegramRetryAfter,
)

from config.settings import config
from storage.repository import AsyncNewsRepository
from services.raw_feed_sync import sync_publication_result
from utils.card_preview_text import (
    normalize_public_title,
    normalize_publication_text,
    public_text_quality_issues,
    to_card_preview_text,
)
from utils.owner_content import (
    build_fallback_merged_text,
    ensure_merged_owner_post,
    strip_author_meta_labels,
)
from utils.item_context import (
    derive_item_title,
    get_item_text_context,
    is_title_only_summary_fallback,
    missing_text_context_summary,
)
from utils.media_utils import (
    is_image_ref,
    is_video_ref,
    iter_media_candidates,
    normalize_media_ref,
)
from utils.telegram_editorial import TELEGRAM_HARD_CHARS
from utils.telegram_media_input import (
    PHOTO_MAX_BYTES,
    VIDEO_MAX_BYTES,
    http_url_as_input_file,
)

if TYPE_CHECKING:  # pragma: no cover - typing helper
    from aiogram.types import FSInputFile as AiogramFSInputFile
    from aiogram import Bot as AiogramBot
else:  # pragma: no cover - fallback when aiogram is absent (e.g. unit tests)
    AiogramBot = Any
    AiogramFSInputFile = Any

try:  # pragma: no cover - import availability depends on test env
    from aiogram.types import FSInputFile
except Exception:  # noqa: BLE001
    FSInputFile = None  # type: ignore[assignment]

LOGGER = logging.getLogger(__name__)

# Telegram считает лимит 1024 по видимому тексту; len() с HTML-тегами даёт запас.
_CAPTION_LIMIT = 1000


def _utc_now() -> datetime:
    """Return current UTC time as timezone-aware datetime."""

    return datetime.now(timezone.utc)


class PublicationSendError(Exception):
    """Raised when the Telegram API keeps failing after retries."""

    def __init__(self, attempts: int, cause: BaseException):
        super().__init__(str(cause))
        self.attempts = attempts
        self.cause = cause


async def _send_with_retry(
    method,
    *,
    attempts: int,
    delay_seconds: float,
    **kwargs: Any,
):
    """Only retry explicit rate-limit rejection, never an ambiguous transport error."""
    for counter in range(1, max(1, attempts) + 1):
        try:
            return await method(**kwargs), counter
        except TelegramRetryAfter as exc:
            if counter >= max(1, attempts):
                raise PublicationSendError(counter, exc) from exc
            await asyncio.sleep(max(0.0, delay_seconds, float(exc.retry_after)))
        except Exception as exc:
            raise PublicationSendError(counter, exc) from exc


class PartialPublicationError(Exception):
    """Media was accepted, but the final text delivery could not be completed."""


def _definite_rejection(error: BaseException) -> bool:
    cause = getattr(error, "cause", error)
    return isinstance(
        cause,
        (
            TelegramBadRequest,
            TelegramForbiddenError,
            TelegramNotFound,
            TelegramRetryAfter,
        ),
    )


class PublicationService:
    """High-level orchestrator that publishes queued items into Telegram."""

    def __init__(
        self,
        repository: AsyncNewsRepository,
        bot: AiogramBot,
        channel_id: str | int | None,
        *,
        now_func: Callable[[], datetime] = _utc_now,
    ) -> None:
        self._repository = repository
        self._bot = bot
        self._channel_id = channel_id
        self._now = now_func
        self._retry_minutes = config.PUBLICATION_RETRY_MINUTES
        self._max_attempts = max(1, config.PUBLICATION_MAX_ATTEMPTS)
        self._immediate_attempts = max(1, config.PUBLICATION_IMMEDIATE_RETRIES)
        self._immediate_delay = config.PUBLICATION_IMMEDIATE_DELAY_SECONDS
        self._retry_max_age_hours = max(
            0.0, float(config.PUBLICATION_RETRY_MAX_AGE_HOURS)
        )

    async def publish_pending(self, limit: int = 5) -> int:
        """Publish queued items and return number of successes."""

        channel_id = self._resolve_channel_id()
        if channel_id is None:
            LOGGER.warning(
                "CHANNEL_ID / TELEGRAM_CHANNEL_ID не задан в .env — очередь публикаций пропускается"
            )
            return 0

        fetch_limit = max(limit, limit * 20)
        items = await self._repository.list_publication_candidates(limit=fetch_limit)
        if not items:
            return 0

        published = 0
        considered = 0
        for item in items:
            if self._is_stale_retry_candidate(item):
                continue
            if self._is_scheduled_for_future(item):
                continue
            item_id = item["id"]
            nlp = await self._repository.get_nlp_results(item_id) or {}
            if not self._has_author_notes(nlp):
                await self._handle_missing_author_notes(
                    item_id, str(item.get("status") or "")
                )
                continue
            from services.editorial_layers import (
                extract_editorial_layers,
                publication_allowed,
            )

            layers = extract_editorial_layers(item, nlp)
            allowed, deny_reason = publication_allowed(layers)
            if not allowed:
                await self._handle_missing_author_notes(
                    item_id, str(item.get("status") or "")
                )
                await self._repository.log_event(
                    item_id,
                    "warning",
                    "editorial_policy_block",
                    {"reason": deny_reason},
                )
                continue
            if is_title_only_summary_fallback(item, nlp):
                await self._handle_untrusted_summary(
                    item_id, str(item.get("status") or "")
                )
                continue
            merged_text = await ensure_merged_owner_post(item, nlp)
            if merged_text and merged_text != str(nlp.get("merged_text") or "").strip():
                await self._repository.save_nlp_results(
                    item_id,
                    summary=nlp.get("summary"),
                    questions=nlp.get("questions"),
                    decision=nlp.get("decision"),
                    moderation=nlp.get("moderation"),
                    extra=nlp.get("extra"),
                    merged_text=merged_text,
                    voice_file=nlp.get("voice_file"),
                    rewrite_guidance=nlp.get("rewrite_guidance"),
                )
                nlp = {**nlp, "merged_text": merged_text}
            quality_issues = self._publication_quality_issues(item, nlp)
            if quality_issues:
                await self._handle_needs_cleanup(
                    item_id, str(item.get("status") or ""), quality_issues
                )
                continue
            caption = self._build_caption(item, nlp)
            if self._telegram_caption_too_long(caption):
                await self._handle_needs_cleanup(
                    item_id,
                    str(item.get("status") or ""),
                    ["telegram_caption_too_long"],
                )
                continue
            considered += 1
            if considered > limit:
                break
            attempt_count, allowed, next_time = await self._should_attempt(item_id)
            if not allowed:
                if next_time is not None:
                    await self._repository.log_event(
                        item_id,
                        "info",
                        "publication_waiting",
                        {"next_attempt": next_time.isoformat()},
                    )
                continue

            token = await self._repository.claim_publication(item_id, str(channel_id))
            if token is None:
                continue
            try:
                message = await self._publish_item(channel_id, item)
            except (
                Exception
            ) as exc:  # cancellation/crash deliberately retains the durable claim
                if _definite_rejection(exc):
                    await self._handle_failure(
                        item_id,
                        attempt_count + 1,
                        str(getattr(exc, "cause", exc)),
                        item=item,
                    )
                    await self._repository.release_publication_rejection(item_id, token)
                else:
                    await self._repository.mark_publication_unknown(
                        item_id, token, type(exc).__name__
                    )
                    LOGGER.error(
                        "publication delivery requires reconciliation item_id=%s",
                        item_id,
                    )
            else:
                try:
                    await self._repository.complete_publication(
                        item_id, token, str(channel_id), str(message.message_id)
                    )
                except Exception:
                    # Telegram may already have accepted it. Never release/retry this claim.
                    LOGGER.exception(
                        "publication ACK bookkeeping failed item_id=%s", item_id
                    )
                    raise
                published += 1
                try:
                    await self._handle_success(
                        item_id, channel_id, message.message_id, item=item
                    )
                except Exception:
                    # Sheets/site failure cannot turn a committed delivery into a retry.
                    LOGGER.exception(
                        "publication post-delivery sync failed item_id=%s", item_id
                    )
        return published

    def _is_scheduled_for_future(self, item: Mapping[str, Any]) -> bool:
        raw = str(item.get("scheduled_at") or "").strip()
        if not raw:
            return False
        try:
            when = datetime.fromisoformat(raw)
        except ValueError:
            return False
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        else:
            when = when.astimezone(timezone.utc)
        return when > self._now()

    def _is_stale_retry_candidate(self, item: Mapping[str, Any]) -> bool:
        if item.get("status") != "publish_retry":
            return False
        if self._retry_max_age_hours <= 0:
            return False
        raw_ts = item.get("updated_at") or item.get("created_at")
        if not raw_ts:
            return False
        try:
            ts = datetime.fromisoformat(str(raw_ts))
        except ValueError:
            return False
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        else:
            ts = ts.astimezone(timezone.utc)
        max_age = timedelta(hours=self._retry_max_age_hours)
        return self._now() - ts > max_age

    async def _publish_item(self, channel_id: int | str, item: Mapping[str, Any]):
        item_id = item["id"]
        nlp = await self._repository.get_nlp_results(item_id) or {}
        text = self._build_caption(item, nlp)
        cover_photo = self._extract_cover_photo(item, nlp)
        video_ref = self._extract_video_ref(item)
        if not cover_photo and not video_ref:
            enriched = await self._hydrate_media(item_id, item)
            if enriched is not None:
                cover_photo = self._extract_cover_photo(enriched, nlp)
                video_ref = self._extract_video_ref(enriched)

        media_attempts: list[tuple[str, Any, dict[str, Any]]] = []
        if video_ref:
            media_attempts.append(("video", self._bot.send_video, {"video": video_ref}))
        if cover_photo:
            media_attempts.append(
                ("photo", self._bot.send_photo, {"photo": cover_photo})
            )
        LOGGER.info(
            "publication media item_id=%s kinds=%s text_len=%s",
            item_id,
            ",".join(kind for kind, _, _ in media_attempts) or "none",
            len(text),
        )

        send = partial(
            _send_with_retry,
            attempts=self._immediate_attempts,
            delay_seconds=self._immediate_delay,
        )

        # Лимит подписи Telegram — 1024 символа; длинный пост (с экспертным
        # мнением) уходит как медиа без подписи + отдельное текстовое сообщение.
        fits_caption = len(text) <= _CAPTION_LIMIT
        media_sent = False

        async def _send_media(method, media_kwargs):
            if fits_caption:
                result, _ = await send(
                    method,
                    chat_id=channel_id,
                    parse_mode="HTML",
                    caption=text,
                    **media_kwargs,
                )
                return result
            await send(method, chat_id=channel_id, **media_kwargs)
            return None

        for kind, method, media_kwargs in media_attempts:
            ref = media_kwargs[kind]
            try:
                result = await _send_media(method, media_kwargs)
            except Exception as err:  # noqa: BLE001
                if not _definite_rejection(err):
                    raise
                cause = getattr(err, "cause", err)
                LOGGER.warning(
                    "publication media send failed item_id=%s kind=%s error=%s: %s",
                    item_id,
                    kind,
                    type(cause).__name__,
                    str(cause)[:200],
                )
                if not (
                    isinstance(ref, str) and ref.startswith(("http://", "https://"))
                ):
                    continue
                # Bot API не смог скачать URL сам — качаем Parser'ом и шлём файлом.
                uploaded = await http_url_as_input_file(
                    ref,
                    max_bytes=VIDEO_MAX_BYTES if kind == "video" else PHOTO_MAX_BYTES,
                )
                if uploaded is None:
                    continue
                try:
                    result = await _send_media(method, {kind: uploaded})
                except Exception as retry_err:  # noqa: BLE001
                    if not _definite_rejection(retry_err):
                        raise
                    LOGGER.warning(
                        "publication media file retry failed item_id=%s kind=%s error=%s",
                        item_id,
                        kind,
                        type(getattr(retry_err, "cause", retry_err)).__name__,
                    )
                    continue
            if result is not None:
                return result
            media_sent = True
            break

        try:
            result, _ = await send(
                self._bot.send_message,
                chat_id=channel_id,
                parse_mode="HTML",
                text=text,
                disable_web_page_preview=media_sent,
            )
        except Exception as exc:
            if media_sent:
                raise PartialPublicationError(
                    "partial_delivery_requires_reconciliation"
                ) from exc
            raise
        return result

    async def _hydrate_media(
        self, item_id: int, item: Mapping[str, Any]
    ) -> Mapping[str, Any] | None:
        """Докачать медиа из источника (TG/og:image) и залить на сайт, если в item его нет."""
        try:
            from services.site_media_client import (
                media_upload_configured,
                prepare_item_media_for_raw_feed,
            )

            if not media_upload_configured():
                return None
            out, _ = await prepare_item_media_for_raw_feed(item_id, item)
        except Exception:  # noqa: BLE001
            LOGGER.exception("publication media hydrate failed item_id=%s", item_id)
            return None
        images = str(out.get("images") or "").strip()
        videos = str(out.get("videos") or "").strip()
        if (images or videos) and hasattr(self._repository, "update_item_media"):
            try:
                await self._repository.update_item_media(
                    item_id,
                    images=images or item.get("images"),
                    videos=videos or item.get("videos"),
                )
            except Exception:  # noqa: BLE001
                LOGGER.exception("publication media persist failed item_id=%s", item_id)
        return out

    async def _handle_failure(
        self,
        item_id: int,
        attempt_number: int,
        error: str,
        *,
        item: Mapping[str, Any] | None = None,
    ) -> None:
        if attempt_number >= self._max_attempts:
            await self._repository.update_status(item_id, "error")
            await self._repository.log_event(
                item_id,
                "error",
                "publication_failed",
                {"attempt": attempt_number, "error": error, "status": "stopped"},
            )
            await self._repository.log_event(
                item_id,
                "error",
                "publication_abandoned",
                {"attempt": attempt_number},
            )
        else:
            await self._repository.update_status(item_id, "publish_retry")
            await self._repository.log_event(
                item_id,
                "error",
                "publication_failed",
                {"attempt": attempt_number, "error": error},
            )
        sheet_item = item
        if sheet_item is None and hasattr(self._repository, "get_item"):
            try:
                sheet_item = await self._repository.get_item(item_id)
            except aiosqlite.Error:
                sheet_item = None
        nlp = await self._repository.get_nlp_results(item_id) or {}
        if sheet_item:
            await sync_publication_result(sheet_item, nlp, published=False, error=error)

    async def _handle_success(
        self,
        item_id: int,
        channel_id: int | str,
        message_id: int,
        *,
        item: Mapping[str, Any] | None = None,
    ) -> None:
        # Receipt/status/log were committed atomically before external synchronization.
        sheet_item = item
        if sheet_item is None and hasattr(self._repository, "get_item"):
            try:
                sheet_item = await self._repository.get_item(item_id)
            except aiosqlite.Error:
                sheet_item = None
        nlp = await self._repository.get_nlp_results(item_id) or {}
        if sheet_item:
            await sync_publication_result(sheet_item, nlp, published=True)

    async def _handle_missing_author_notes(
        self, item_id: int, status_from: str
    ) -> None:
        await self._repository.update_status(item_id, "review")
        await self._repository.log_event(
            item_id,
            "warning",
            "publication_blocked_missing_author_note",
            {"status_from": status_from, "required_action": "owner_comment"},
        )

    async def _handle_untrusted_summary(self, item_id: int, status_from: str) -> None:
        await self._repository.update_status(item_id, "review")
        await self._repository.log_event(
            item_id,
            "warning",
            "publication_blocked_untrusted_summary",
            {
                "status_from": status_from,
                "required_action": "open_source_and_rewrite",
            },
        )

    async def _handle_needs_cleanup(
        self, item_id: int, status_from: str, issues: list[str]
    ) -> None:
        await self._repository.update_status(item_id, "review")
        await self._repository.log_event(
            item_id,
            "warning",
            "publication_blocked_needs_cleanup",
            {
                "status_from": status_from,
                "issues": issues,
                "required_action": "rewrite_or_regenerate",
            },
        )

    async def _should_attempt(self, item_id: int) -> tuple[int, bool, datetime | None]:
        last_failure = await self._repository.get_last_log(
            item_id, "publication_failed"
        )
        if last_failure is None:
            return 0, True, None
        meta = last_failure.get("meta") or {}
        attempt = int(meta.get("attempt", 1))
        if attempt >= self._max_attempts:
            await self._repository.update_status(item_id, "error")
            await self._repository.log_event(
                item_id,
                "error",
                "publication_abandoned",
                {"attempt": attempt},
            )
            return attempt, False, None
        delay_minutes = self._retry_minutes[
            min(attempt - 1, len(self._retry_minutes) - 1)
        ]
        if delay_minutes <= 0:
            return attempt, True, None
        try:
            last_time = datetime.fromisoformat(str(last_failure["created_at"]))
        except (KeyError, ValueError):  # pragma: no cover - defensive
            return attempt, True, None
        next_time = last_time + timedelta(minutes=delay_minutes)
        if self._now() < next_time:
            return attempt, False, next_time
        return attempt, True, None

    def _resolve_channel_id(self) -> int | str | None:
        if self._channel_id in (None, ""):
            return None
        try:
            return int(self._channel_id)  # type: ignore[arg-type]
        except (TypeError, ValueError):
            return self._channel_id

    @classmethod
    def _extract_cover_photo(
        cls, item: Mapping[str, Any], nlp: Mapping[str, Any]
    ) -> str | AiogramFSInputFile | None:
        # Локальный файл (скачан media_pipeline) надёжнее URL: Bot API не нужно ничего качать.
        for key in ("cover_image_url", "image_url", "images"):
            for media_type, raw_candidate in iter_media_candidates(item.get(key)):
                candidate = normalize_media_ref(
                    raw_candidate, media_type=media_type or "image"
                )
                if not candidate or candidate.startswith(("http://", "https://")):
                    continue
                if is_video_ref(candidate, media_type=media_type):
                    continue
                photo = cls._cover_photo_input(candidate)
                if photo:
                    return photo

        for key in ("cover_image_url", "image_url"):
            candidate = normalize_media_ref(item.get(key), media_type="image")
            photo = cls._cover_photo_input(candidate)
            if photo:
                return photo

        for key in ("images", "raw_media", "media_json"):
            for media_type, raw_candidate in iter_media_candidates(item.get(key)):
                candidate = normalize_media_ref(raw_candidate, media_type=media_type)
                if not candidate:
                    continue
                if not is_image_ref(candidate, media_type=media_type) or is_video_ref(
                    candidate,
                    media_type=media_type,
                ):
                    continue
                photo = cls._cover_photo_input(candidate)
                if photo:
                    return photo

        extra = nlp.get("extra")
        if not isinstance(extra, Mapping):
            return None
        cover = extra.get("cover")
        if not isinstance(cover, Mapping):
            return None
        url = cover.get("url")
        return (
            cls._cover_photo_input(str(url)) if isinstance(url, str) and url else None
        )

    @staticmethod
    def _cover_photo_input(cover_url: str | None) -> str | AiogramFSInputFile | None:
        if not cover_url:
            return None
        if cover_url.startswith("/static/"):
            rel = cover_url.removeprefix("/static/").lstrip("/")
            path = Path(rel)
            if path.is_file() and FSInputFile is not None:
                return FSInputFile(str(path))
            return None
        if cover_url.startswith(("http://", "https://")):
            parsed = urlparse(cover_url)
            host = (parsed.hostname or "").lower()
            if host in {"127.0.0.1", "localhost"}:
                if parsed.path.startswith("/static/"):
                    return PublicationService._cover_photo_input(parsed.path)
                return None
            # t.me/... — страница поста, а не файл; Telegram не примет её как фото.
            if host in {"t.me", "telegram.me", "www.t.me"}:
                return None
            return cover_url
        # Локальный путь (downloads/123.jpg) нужно слать файлом, иначе Bot API
        # считает строку file_id и отклоняет запрос.
        path = Path(cover_url)
        if path.is_file() and FSInputFile is not None:
            return FSInputFile(str(path))
        return None

    @staticmethod
    def _has_author_notes(nlp: Mapping[str, Any]) -> bool:
        return bool(str(nlp.get("author_notes") or "").strip())

    @staticmethod
    def _publication_quality_issues(
        item: Mapping[str, Any], nlp: Mapping[str, Any]
    ) -> list[str]:
        merged = str(nlp.get("merged_text") or "").strip()
        summary = str(nlp.get("summary") or "").strip()
        body = merged or summary or str(get_item_text_context(item) or "")
        clean_body = normalize_publication_text(body, preserve_paragraphs=True)
        title = normalize_public_title(derive_item_title(item, max_len=140))
        excerpt = to_card_preview_text(clean_body, max_len=260)
        return public_text_quality_issues(title=title, excerpt=excerpt, body=clean_body)

    @staticmethod
    def _telegram_caption_too_long(caption: str) -> bool:
        """Hard limit Telegram API: message/caption text cannot exceed 4096 chars."""
        return len(caption or "") > TELEGRAM_HARD_CHARS

    @staticmethod
    def _extract_video_ref(item: Mapping[str, Any]) -> str | AiogramFSInputFile | None:
        for raw in str(item.get("videos") or "").splitlines():
            normalized = normalize_media_ref(raw.strip())
            if (
                normalized
                and not normalized.startswith(("http://", "https://"))
                and is_video_ref(normalized)
            ):
                ref = PublicationService._cover_photo_input(normalized)
                if ref:
                    return ref
        for media_type, raw in iter_media_candidates(item.get("media_json")):
            if is_video_ref(raw, media_type=media_type):
                ref = PublicationService._cover_photo_input(normalize_media_ref(raw))
                if ref:
                    return ref
        for raw in str(item.get("videos") or "").splitlines():
            normalized = normalize_media_ref(raw.strip())
            if normalized and is_video_ref(normalized):
                ref = PublicationService._cover_photo_input(normalized)
                if ref:
                    return ref
        for media_type, raw in iter_media_candidates(item.get("raw_media")):
            if is_video_ref(raw, media_type=media_type):
                ref = PublicationService._cover_photo_input(normalize_media_ref(raw))
                if ref:
                    return ref
        return None

    @staticmethod
    def _build_caption(item: Mapping[str, Any], nlp: Mapping[str, Any]) -> str:
        summary = str(nlp.get("summary") or "").strip()
        notes = str(nlp.get("author_notes") or "").strip()
        merged_text = strip_author_meta_labels(
            str(nlp.get("merged_text") or "").strip()
        )
        title = html.escape(
            normalize_public_title(derive_item_title(item, max_len=140))
        )

        parts: list[str] = []
        if is_title_only_summary_fallback(item, nlp):
            body = missing_text_context_summary(item)
            parts.append(f"<b>{title}</b>")
            if body:
                parts.append(html.escape(str(body)))
        elif (
            str(nlp.get("merged_text") or "").strip()
            and isinstance(nlp.get("extra"), Mapping)
            and nlp["extra"].get("owner_manual_final_text") is True
        ):
            # The Owner submitted the complete body: keep it verbatim and escaped.
            parts.append(html.escape(str(nlp["merged_text"]).strip()))
        elif summary and notes:
            # Короткий факт + ярко выделенное экспертное мнение Owner.
            short_summary = to_card_preview_text(
                normalize_publication_text(summary, preserve_paragraphs=True),
                max_len=520,
            )
            parts.append(f"<b>{title}</b>")
            if short_summary:
                parts.append(html.escape(short_summary))
            notes_clean = normalize_publication_text(notes, preserve_paragraphs=True)
            parts.append(
                "<b>💬 Экспертное мнение</b>\n" f"<b>{html.escape(notes_clean)}</b>"
            )
        elif merged_text:
            body = normalize_publication_text(merged_text, preserve_paragraphs=True)
            if body:
                parts.append(html.escape(body))
        elif notes:
            merged_fallback = build_fallback_merged_text(
                source_text=summary or get_item_text_context(item) or "",
                author_notes=notes,
                title=derive_item_title(item, max_len=140),
            )
            body = normalize_publication_text(merged_fallback, preserve_paragraphs=True)
            if body:
                parts.append(html.escape(body))
        else:
            parts.append(f"<b>{title}</b>")
            body = normalize_publication_text(
                summary or get_item_text_context(item) or "",
                preserve_paragraphs=True,
            )
            if body:
                parts.append(html.escape(body))

        source_url = str(item.get("link") or item.get("source_url") or "").strip()
        site_url = str(
            getattr(config, "PUBLICATION_SITE_URL", "") or "https://mywavewake.ru/"
        ).strip()
        admin_url = str(
            getattr(config, "PUBLICATION_ADMIN_BOT_URL", "")
            or "https://t.me/MyWave_Admin_bot"
        ).strip()
        footer_bits: list[str] = []
        if source_url.lower().startswith(("http://", "https://")):
            footer_bits.append(
                f'<a href="{html.escape(source_url, quote=True)}">Источник</a>'
            )
        if site_url:
            footer_bits.append(
                f'<a href="{html.escape(site_url, quote=True)}">сайт</a>'
            )
        if admin_url:
            footer_bits.append(
                f'<a href="{html.escape(admin_url, quote=True)}">тг-админ</a>'
            )
        if footer_bits:
            parts.append(" · ".join(footer_bits))
        return "\n\n".join(p for p in parts if p)


__all__ = ["PublicationService", "PublicationSendError"]
